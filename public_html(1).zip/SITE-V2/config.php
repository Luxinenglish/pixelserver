<?php
// Paramètres de connexion à la base de données
$servername = "localhost";
$dbusername = "root"; // Remplacez par votre nom d'utilisateur MySQL
$dbpassword = ""; // Remplacez par votre mot de passe MySQL
$dbname = "pixelserver";

// Connexion à la base de données
$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

// Vérifier la connexion
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}
?>
