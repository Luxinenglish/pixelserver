<?php
session_start();
require 'config.php';

// Gestion de l'inscription
if (isset($_POST['register'])) {
    $user = $_POST['username'];
    $pass = password_hash($_POST['password'], PASSWORD_BCRYPT);

    $sql = $conn->prepare("INSERT INTO user (username, password) VALUES (?, ?)");
    $sql->bind_param("ss", $user, $pass);

    if ($sql->execute()) {
        echo "Inscription réussie ! Vous pouvez maintenant vous connecter.";
    } else {
        echo "Erreur : " . $sql->error;
    }

    $sql->close();
}

// Gestion de la connexion
if (isset($_POST['login'])) {
    $user = $_POST['username'];
    $pass = $_POST['password'];

    $sql = $conn->prepare("SELECT * FROM user WHERE username = ?");
    $sql->bind_param("s", $user);
    $sql->execute();
    $result = $sql->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        
        if (password_verify($pass, $row['password'])) {
            $_SESSION['username'] = $user;
            echo "Connexion réussie ! Bienvenue, " . $_SESSION['username'];
        } else {
            echo "Mot de passe incorrect.";
        }
    } else {
        echo "Nom d'utilisateur incorrect.";
    }

    $sql->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Connexion et Inscription</title>
</head>
<body>
    <h2>Connexion</h2>
    <form method="post">
        <label for="login_username">Nom d'utilisateur :</label>
        <input type="text" id="login_username" name="username" required><br><br>
        <label for="login_password">Mot de passe :</label>
        <input type="password" id="login_password" name="password" required><br><br>
        <button type="submit" name="login">Se connecter</button>
    </form>

    <h2>Inscription</h2>
    <form method="post">
        <label for="register_username">Nom d'utilisateur :</label>
        <input type="text" id="register_username" name="username" required><br><br>
        <label for="register_password">Mot de passe :</label>
        <input type="password" id="register_password" name="password" required><br><br>
        <button type="submit" name="register">S'inscrire</button>
    </form>
</body>
</html>
